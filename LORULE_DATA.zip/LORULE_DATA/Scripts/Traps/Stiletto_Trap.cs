﻿using Darkages.Scripting;
using Darkages.Types;

namespace Darkages.Assets.locales.Scripts.Traps
{
    [Script("Stiletto Trap", "Dean")]
    public class Stiletto_Trap : TrapScript
    {
        public Stiletto_Trap(Trap _lptrap) : base(_lptrap)
        {

        }

        public override void OnActivated(Sprite owner)
        {

        }

        public override void OnTripped(Sprite owner, Sprite target)
        {

        }
    }
}
