﻿///************************************************************************
//Project Lorule: A Dark Ages Server (http://darkages.creatorlink.net/index/)
//Copyright(C) 2018 TrippyInc Pty Ltd
//
//This program is free software: you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation, either version 3 of the License, or
//(at your option) any later version.
//
//This program is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.See the
//GNU General Public License for more details.
//
//You should have received a copy of the GNU General Public License
//along with this program.If not, see<http://www.gnu.org/licenses/>.
//*************************************************************************/
namespace Darkages.Network.ClientFormats
{
    public class ClientFormat01
    {
    }

    //public class ClientFormat02 { } Added (Create Stage A)
    //public class ClientFormat03 { } Added (Create Stage B)
    //public class ClientFormat04 { } Added (Log In)
    //public class ClientFormat05 { } Added (Area Request)
    //public class ClientFormat06 { } Added (Walk)
    //public class ClientFormat07 { } pickup gold?
    //public class ClientFormat08 { } Added (Drop Item)
    public class ClientFormat09
    {
    }

    public class ClientFormat0A
    {
    }

    //public class ClientFormat0B { } Added (Client Disconnected)
    public class ClientFormat0C
    {
    }

    public class ClientFormat0D
    {
    }

    //public class ClientFormat0E { } Added (Chat)
    //public class ClientFormat0F { } Added (Use Spell)
    //public class ClientFormat11 { } Added (Turn)
    public class ClientFormat12
    {
    }

    //public class ClientFormat13 { } (Spacebar Attack)
    public class ClientFormat14
    {
    }

    public class ClientFormat15
    {
    }

    public class ClientFormat16
    {
    }

    public class ClientFormat17
    {
    }

    //public class ClientFormat18 { } Added (Request User List)

    // public class ClientFormat19 { } Added (Private Messages)

    public class ClientFormat1A
    {
    }

    //public class ClientFormat1B { } Added - Settings Requested

    //public class ClientFormat1C { } Added (Use Item)
    //public class ClientFormat1D { } Added (Emote)
    public class ClientFormat1E
    {
    }

    public class ClientFormat1F
    {
    }

    public class ClientFormat20
    {
    }

    public class ClientFormat21
    {
    }

    public class ClientFormat22
    {
    }

    public class ClientFormat23
    {
    }

    //public class ClientFormat24 { } Added (Drop Gold)
    public class ClientFormat25
    {
    }

    //public class ClientFormat26 { } Added (Change Password)
    public class ClientFormat27
    {
    }

    public class ClientFormat28
    {
    }

    //public class ClientFormat29 { ] Added (Exchange Item)


    //public class ClientFormat2A { } Added (Exchange Gold)

    public class ClientFormat2B
    {
    }

    public class ClientFormat2C
    {
    }

    //public class ClientFormat2D { } Added
    //public class ClientFormat2E { }
    //public class ClientFormat2F { } // Added

    //public class ClientFormat30 { } //swap skill item.
    public class ClientFormat31
    {
    }

    public class ClientFormat32
    {
    }

    public class ClientFormat33
    {
    }

    public class ClientFormat34
    {
    }

    public class ClientFormat35
    {
    }

    public class ClientFormat36
    {
    }

    public class ClientFormat37
    {
    }

    //public class ClientFormat38 { } Added
    //public class ClientFormat39 { } Added (Mundane Dialog Response)
    //public class ClientFormat3A { }
    // public class ClientFormat3B { } // boards

    public class ClientFormat3C
    {
    }

    public class ClientFormat3D
    {
    }

    //public class ClientFormat3E { } Added (Use Skill)
    //public class ClientFormat3F
    //{
    //} // (Map Click)

    public class ClientFormat40
    {
    }

    public class ClientFormat41
    {
    }

    public class ClientFormat42
    {
    }

    //public class ClientFormat43 { } Added (Click)
    //public class ClientFormat44 { } Added (Unequip)
    //public class ClientFormat45 { }
    public class ClientFormat46
    {
    }

    //public class ClientFormat47 { } (Click Stat)
    public class ClientFormat48
    {
    }

    public class ClientFormat49
    {
    }

    // public class ClientFormat4A { } Added (Complete Exchange)

    //public class ClientFormat4B { }
    public class ClientFormat4C
    {
    }

    //public class ClientFormat4D { } Added (Use Spell ClickTarget)
    //public class ClientFormat4E { }
    //public class ClientFormat4F { } Added
    public class ClientFormat50
    {
    }

    public class ClientFormat51
    {
    }

    public class ClientFormat52
    {
    }

    public class ClientFormat53
    {
    }

    public class ClientFormat54
    {
    }

    public class ClientFormat55
    {
    }

    public class ClientFormat56
    {
    }

    public class ClientFormat58
    {
    }

    public class ClientFormat59
    {
    }

    public class ClientFormat5A
    {
    }

    public class ClientFormat5B
    {
    }

    public class ClientFormat5C
    {
    }

    public class ClientFormat5D
    {
    }

    public class ClientFormat5E
    {
    }

    public class ClientFormat5F
    {
    }

    public class ClientFormat60
    {
    }

    public class ClientFormat61
    {
    }

    public class ClientFormat62
    {
    }

    public class ClientFormat63
    {
    }

    public class ClientFormat64
    {
    }

    public class ClientFormat65
    {
    }

    //public class ClientFormat66
    //{
    //}

    public class ClientFormat67
    {
    }

    public class ClientFormat69
    {
    }

    public class ClientFormat6A
    {
    }

    public class ClientFormat6B
    {
    }

    public class ClientFormat6C
    {
    }

    public class ClientFormat6D
    {
    }

    public class ClientFormat6E
    {
    }

    public class ClientFormat6F
    {
    }

    public class ClientFormat70
    {
    }

    public class ClientFormat71
    {
    }

    public class ClientFormat72
    {
    }

    public class ClientFormat73
    {
    }

    public class ClientFormat74
    {
    }

    //public class ClientFormat75 { } Added
    public class ClientFormat76
    {
    }

    public class ClientFormat77
    {
    }

    public class ClientFormat78
    {
    }

    //  public class ClientFormat79 { } Added Profile Data
    public class ClientFormat7A
    {
    }

    //public class ClientFormat7B { } Added (Metafile)
    public class ClientFormat7C
    {
    }

    public class ClientFormat7D
    {
    }

    public class ClientFormat7E
    {
    }

    public class ClientFormat7F
    {
    }

    public class ClientFormat80
    {
    }

    public class ClientFormat81
    {
    }

    public class ClientFormat82
    {
    }

    public class ClientFormat83
    {
    }

    public class ClientFormat84
    {
    }

    public class ClientFormat85
    {
    }

    public class ClientFormat86
    {
    }

    public class ClientFormat87
    {
    }

    public class ClientFormat88
    {
    }

    //public class ClientFormat89 { } Display mask
    public class ClientFormat8A
    {
    }

    public class ClientFormat8B
    {
    }

    public class ClientFormat8C
    {
    }

    public class ClientFormat8D
    {
    }

    public class ClientFormat8E
    {
    }

    public class ClientFormat8F
    {
    }

    public class ClientFormat90
    {
    }

    public class ClientFormat91
    {
    }

    public class ClientFormat92
    {
    }

    public class ClientFormat93
    {
    }

    public class ClientFormat94
    {
    }

    public class ClientFormat95
    {
    }

    public class ClientFormat96
    {
    }

    public class ClientFormat97
    {
    }

    public class ClientFormat98
    {
    }

    public class ClientFormat99
    {
    }

    public class ClientFormat9A
    {
    }

    public class ClientFormat9B
    {
    }

    public class ClientFormat9C
    {
    }

    public class ClientFormat9D
    {
    }

    public class ClientFormat9E
    {
    }

    public class ClientFormat9F
    {
    }

    public class ClientFormatA0
    {
    }

    public class ClientFormatA1
    {
    }

    public class ClientFormatA2
    {
    }

    public class ClientFormatA3
    {
    }

    public class ClientFormatA4
    {
    }

    public class ClientFormatA5
    {
    }

    public class ClientFormatA6
    {
    }

    public class ClientFormatA7
    {
    }

    public class ClientFormatA8
    {
    }

    public class ClientFormatA9
    {
    }

    public class ClientFormatAA
    {
    }

    public class ClientFormatAB
    {
    }

    public class ClientFormatAC
    {
    }

    public class ClientFormatAD
    {
    }

    public class ClientFormatAE
    {
    }

    public class ClientFormatAF
    {
    }

    public class ClientFormatB0
    {
    }

    public class ClientFormatB1
    {
    }

    public class ClientFormatB2
    {
    }

    public class ClientFormatB3
    {
    }

    public class ClientFormatB4
    {
    }

    public class ClientFormatB5
    {
    }

    public class ClientFormatB6
    {
    }

    public class ClientFormatB7
    {
    }

    public class ClientFormatB8
    {
    }

    public class ClientFormatB9
    {
    }

    public class ClientFormatBA
    {
    }

    public class ClientFormatBB
    {
    }

    public class ClientFormatBC
    {
    }

    public class ClientFormatBD
    {
    }

    public class ClientFormatBE
    {
    }

    public class ClientFormatBF
    {
    }

    public class ClientFormatC0
    {
    }

    public class ClientFormatC1
    {
    }

    public class ClientFormatC2
    {
    }

    public class ClientFormatC3
    {
    }

    public class ClientFormatC4
    {
    }

    public class ClientFormatC5
    {
    }

    public class ClientFormatC6
    {
    }

    public class ClientFormatC7
    {
    }

    public class ClientFormatC8
    {
    }

    public class ClientFormatC9
    {
    }

    public class ClientFormatCA
    {
    }

    public class ClientFormatCB
    {
    }

    public class ClientFormatCC
    {
    }

    public class ClientFormatCD
    {
    }

    public class ClientFormatCE
    {
    }

    public class ClientFormatCF
    {
    }

    public class ClientFormatD0
    {
    }

    public class ClientFormatD1
    {
    }

    public class ClientFormatD2
    {
    }

    public class ClientFormatD3
    {
    }

    public class ClientFormatD4
    {
    }

    public class ClientFormatD5
    {
    }

    public class ClientFormatD6
    {
    }

    public class ClientFormatD7
    {
    }

    public class ClientFormatD8
    {
    }

    public class ClientFormatD9
    {
    }

    public class ClientFormatDA
    {
    }

    public class ClientFormatDB
    {
    }

    public class ClientFormatDC
    {
    }

    public class ClientFormatDD
    {
    }

    public class ClientFormatDE
    {
    }

    public class ClientFormatDF
    {
    }

    public class ClientFormatE0
    {
    }

    public class ClientFormatE1
    {
    }

    public class ClientFormatE2
    {
    }

    public class ClientFormatE3
    {
    }

    public class ClientFormatE4
    {
    }

    public class ClientFormatE5
    {
    }

    public class ClientFormatE6
    {
    }

    public class ClientFormatE7
    {
    }

    public class ClientFormatE8
    {
    }

    public class ClientFormatE9
    {
    }

    public class ClientFormatEA
    {
    }

    public class ClientFormatEB
    {
    }

    public class ClientFormatEC
    {
    }

    public class ClientFormatED
    {
    }

    public class ClientFormatEE
    {
    }

    public class ClientFormatEF
    {
    }

    public class ClientFormatF0
    {
    }

    public class ClientFormatF1
    {
    }

    public class ClientFormatF2
    {
    }

    public class ClientFormatF3
    {
    }

    public class ClientFormatF4
    {
    }

    public class ClientFormatF5
    {
    }

    public class ClientFormatF6
    {
    }

    public class ClientFormatF7
    {
    }

    public class ClientFormatF8
    {
    }

    public class ClientFormatF9
    {
    }

    public class ClientFormatFA
    {
    }

    public class ClientFormatFB
    {
    }

    public class ClientFormatFC
    {
    }

    public class ClientFormatFD
    {
    }

    public class ClientFormatFE
    {
    }

    public class ClientFormatFF
    {
    }
}
